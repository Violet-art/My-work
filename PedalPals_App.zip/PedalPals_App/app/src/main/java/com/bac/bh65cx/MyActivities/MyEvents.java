package com.bac.bh65cx.MyActivities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.SearchView;

import com.bac.bh65cx.MyAdapters.ListOfEvents_Adapter;
import com.bac.bh65cx.R;
import com.bac.bh65cx.MyAdapters.TabsNavigationAdapter;

public class MyEvents extends AppCompatActivity {



    Toolbar toolbar;
    ViewPager viewPager;
    TabLayout tabLayout;
    TabsNavigationAdapter tabsAccessAdapter;


    private SearchView searchView;
    private MenuItem searchMenuItem;
    ListOfEvents_Adapter adapter;


        @Override
        protected void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.dashboard);

            toolbar = findViewById(R.id.main_page_toolbar);
            setSupportActionBar(toolbar);
            getSupportActionBar().setTitle("PedalPals");
            toolbar.setTitleTextColor(Color.parseColor("#FFFFFF"));




            viewPager = findViewById(R.id.main_tabs_pages);

            tabsAccessAdapter = new TabsNavigationAdapter(getSupportFragmentManager());

            viewPager.setAdapter(tabsAccessAdapter);



            tabLayout = findViewById(R.id.main_tabs);

            tabLayout.setupWithViewPager(viewPager);

            // tabLayout.setSelectedTabIndicatorColor();
            tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#ffffff"));
            tabLayout.setSelectedTabIndicatorHeight((int) (5 * getResources().getDisplayMetrics().density));
            tabLayout.setTabTextColors(Color.parseColor("#d4d0d0"), Color.parseColor("#d4d0d0"));


        }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main,menu);

        return true;
    }
    Intent  intent;
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case R.id.newE:
                  intent = new Intent(getApplicationContext(), AddEvent.class);
                startActivity(intent);
            case R.id.refresh:
                recreate();
                default:
                    break;


        }
        return super.onOptionsItemSelected(item);
    }



}
